$(document).ready(function() {

  // Agregar método de validación para RUT chileno
  $.validator.addMethod("rutChileno", function(value, element) {

      // Validar que el RUT tenga el formato correcto (8 o 9 dígitos + guión + dígito verificador)
      var rutPattern = /^\d{7,8}-[\dK]$/;
      if (!rutPattern.test(value)) {
          return false;
      }

      // Validar el dígito verificador
      var rutSinGuion = value.replace("-", "");
      var rut = rutSinGuion.slice(0, -1);
      var dv = rutSinGuion.slice(-1);
      var factor = 2;
      var sum = 0;
      for (var i = rut.length - 1; i >= 0; i--) {
          sum += parseInt(rut.charAt(i)) * factor;
          factor = factor === 7 ? 2 : factor + 1;
      }
      var dvCalculado = 11 - (sum % 11);
      dvCalculado = dvCalculado === 11 ? "0" : dvCalculado === 10 ? "K" : dvCalculado.toString();

      return dv === dvCalculado;
  }, "El RUT no es válido (escriba sin puntos y con guión)");

  // Agregar método de validación para correo
  $.validator.addMethod("emailCompleto", function(value, element) {

      // Expresión regular para validar correo electrónico
      var regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z\-0-9]{2,}))$/;

      // Validar correo electrónico con la expresión regular
      return regex.test(value);

  }, 'El formato del correo no es válido');
  
  // Agregar método de validación para que un campo sólo acepte 
  // letras y espacios en blanco, pero no números ni símbolos,
  // ideal para campos como nombres y apellidos
  $.validator.addMethod("soloLetras", function(value, element) {

      return this.optional(element) || /^[a-zA-Z\s]*$/.test(value);

  }, "Sólo se permiten letras y espacios en blanco.");

  // El siguiente Javascript obliga a que la caja de texto del rut, siempre escriba la letra "K" en mayúscula
  if(document.getElementById('rut')) {
      document.getElementById('rut').addEventListener('keyup', function(e) {
          e.target.value = e.target.value.toUpperCase();
      }); 
  }

  // Validar formulario con JQuery
  $("#formulario-registro").validate({
      rules: {
          rut: {
              required: true,
              rutChileno: true
          },
          nombre: {
              required: true,
              soloLetras: true
          },
          apellido: {
              required: true,
              soloLetras: true
          },
          correo: {
              required: true,
              emailCompleto: true,
          },
          direccion: {
              required: true,
          },
          password: {
              required: true,
              minlength: 5,
              maxlength: 15,
          },
          password2: {
              required: true,
              minlength: 5,
              maxlength: 15,
              equalTo: "#password",
          },
      }, // --> Fin de reglas
      messages: {
          rut: {
              required: "El RUT es un campo requerido",
              rutChileno: "El RUT no es válido (escriba sin puntos y con guión)"
          },
          nombre: {
              required: "El nombre es un campo requerido",
              soloLetras: "El nombre sólo puede contener letras y espacios en blanco",
          },
          apellido: {
              required: "El apellido es un campo requerido",
              soloLetras: "El apellido sólo puede contener letras y espacios en blanco",
          },
          correo: {
              required: "El correo es un campo requerido",
              email: "El formato del correo no es válido",
          },
          direccion: {
              required: "La direccion es un campo requerido",
          },
          password: {
              required: "La contraseña es un campo requerido",
              minlength: "La contraseña debe tener un mínimo de 5 caracteres",
              maxlength: "La contraseña debe tener un máximo de 15 caracteres",
          },
          password2: {
              required: "Repetir contraseña es un campo requerido",
              minlength: "Repetir contraseña debe tener un mínimo de 5 caracteres",
              maxlength: "Repetir contraseña debe tener un máximo de 15 caracteres",
              equalTo: "Debe repetir la contraseña escrita anteriormente",
          },
      }, // --> Fin de mensajes
  });

  // Validar formulario con JQuery
  $("#formulario-bodega").validate({
      rules: {
          categoria: {
              required: true,
          },
          nombre: {
              required: true,
          },
          cantidad: {
              required: true,
              number: true,
              min: 1,
          },
      }, // --> Fin de reglas
      messages: {
          categoria: {
              required: "La categoría es un campo requerido",
          },
          nombre: {
              required: "El nombre es un campo requerido",
          },
          cantidad: {
              required: "La cantidad es un campo requerido",
              number: "La cantidad debe ser un número",
              min: "La cantidad debe ser mayor o igual a 1",
          },
      }, // --> Fin de mensajes
  });
  
  $('#crear_usuario_prueba').click(function(event) {
      event.preventDefault();
      $.get('https://randomuser.me/api/?results=1', // API para obtener datos de usuario al azar
          function(data){
              $.each(data.results, function(i, item) { // Recorrer las filas devueltas por la API

                  $('#limpiar_formulario').click();
                  
                  $('#id_rut').val('11.111.111-1');
                  dir = `${item.location.street.number} ${item.location.street.name}\n${item.location.city}\n${item.location.country}`;
                  $('#id_nombre').val(item.login.username);
                  $('#id_apellido').val(item.name.last);
                  $('#id_correo').val(item.email);
                  $('#id_direccion').val(dir);
                  $('#id_subscrito').val(true);
                  $('#id_password1').val('Duoc@123');
                  $('#id_password2').val('Duoc@123');
                  $('#id_imagen').val('');

                  Swal.fire({
                      title: 'Se ha creado un nuevo usuario de prueba',
                      html: 
                          `Se ha llenado el formulario con 
                          los datos de un usuario de prueba al azar, con la password 
                          por defecto: <br><br> <strong> "Duoc@123" </strong> <br><br>Si lo deseas puedes 
                          seleccionar una imagen de perfil y registrar este nuevo 
                          usuario presionando el botón <br><br> <strong> "Registarme" </strong>.`,
                      showClass: {
                          popup: 'animate__animated animate__fadeInDown'
                      },
                      hideClass: {
                          popup: 'animate__animated animate__fadeOutUp'
                      }
                  })
              });
          }
      );
  });
});
